package com.connection.dto;

import lombok.Data;

@Data
public class DistributorProfileDTO {
    private Long id;
    private String username;
    private String fullName;
    private String phoneNumber;
    private AddressDto address; 
}
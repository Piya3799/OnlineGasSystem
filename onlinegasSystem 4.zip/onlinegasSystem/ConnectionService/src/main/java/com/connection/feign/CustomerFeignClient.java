package com.connection.feign;

import org.springframework.cloud.openfeign.FeignClient;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import com.connection.dto.AddressDto;
import com.connection.dto.CustomerProfile;

@FeignClient(name = "authentication-service",url="http://localhost:8081")
public interface CustomerFeignClient {

    @GetMapping("/api/internal/customer/profile/{id}")
    CustomerProfile getCustomerProfile(@PathVariable("id") Long customerId);

    @GetMapping("/api/internal/customer/address/{id}")
    AddressDto getCustomerAddress(@PathVariable("id") Long customerId);
}

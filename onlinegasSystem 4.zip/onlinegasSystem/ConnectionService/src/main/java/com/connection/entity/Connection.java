package com.connection.entity;

import java.time.LocalDate;

import com.connection.enums.ConnectionStatus;
import com.connection.enums.ConnectionType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Entity
@Data
public class Connection {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "conseq") 
	@SequenceGenerator(name="conseq", sequenceName = "Connection_seq", initialValue = 1001)
	private long connectionId;
	
	@Enumerated(EnumType.STRING)
	private ConnectionType connectionType;
	
	private long customerId;
	
	private long distributorId;
	
	
	@Enumerated(EnumType.STRING)
	private ConnectionStatus connectionStatus;
	
	private LocalDate approvedDate;

}

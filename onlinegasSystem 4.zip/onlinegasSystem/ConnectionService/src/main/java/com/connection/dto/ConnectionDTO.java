package com.connection.dto;

import com.connection.enums.ConnectionType;
import lombok.Data;

@Data
public class ConnectionDTO {
    private ConnectionType connectionType;
}


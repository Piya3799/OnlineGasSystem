package com.connection.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connection.dto.AddressDto;
import com.connection.dto.ConnectionDTO;
import com.connection.dto.CustomerProfile;
import com.connection.dto.DistributorProfileDTO;
import com.connection.dto.EmailRequest;
import com.connection.entity.Connection;
import com.connection.enums.ConnectionStatus;
import com.connection.enums.ConnectionType;
import com.connection.exception.ResourceNotFoundException;
import com.connection.feign.CustomerFeignClient;
import com.connection.feign.DistributorFeignClient;
import com.connection.feign.EmailFeignClient;
import com.connection.repository.ConnectionRepository;

@Service
public class ConnectionServiceImpl implements ConnectionService{
	
	@Autowired
	private ConnectionRepository repository;
	
	@Autowired
	private CustomerFeignClient customerFeignClient;
	
	@Autowired
	private DistributorFeignClient distributorFeignClient;
	
	@Autowired
	private EmailFeignClient emailFeignClient;
	
	@Override
	public Connection createConnection(ConnectionDTO connectionDto, long customerId) {
		
	  // Check for existing connections first
	  List<Connection> existingConnections = repository.findByCustomerId(customerId);
	 
	  boolean hasPendingDomestic = false;
	  boolean hasApprovedDomestic = false;
	  int pendingCommercialCount = 0;
	  int approvedCommercialCount = 0;

	  for (Connection existing : existingConnections) {
	      ConnectionType type = existing.getConnectionType();
	      ConnectionStatus status = existing.getConnectionStatus();

	      if (type == ConnectionType.DOMESTIC) {
	          if (status == ConnectionStatus.APPROVED) {
	              hasApprovedDomestic = true;
	          } else if (status == ConnectionStatus.PENDING) {
	              hasPendingDomestic = true;
	          }
	      } else if (type == ConnectionType.COMMERCIAL) {
	          if (status == ConnectionStatus.APPROVED) {
	              approvedCommercialCount++;
	          } else if (status == ConnectionStatus.PENDING) {
	              pendingCommercialCount++;
	          }
	      }
	  }

	 
	  ConnectionType requestedType = connectionDto.getConnectionType();

	  if (requestedType == ConnectionType.DOMESTIC &&
	      (hasApprovedDomestic || hasPendingDomestic)) {
	      throw new IllegalStateException("Customer already has a DOMESTIC connection.");
	  } else if (requestedType == ConnectionType.COMMERCIAL &&
	      (approvedCommercialCount + pendingCommercialCount) >= 2) {
	      throw new IllegalStateException("Customer already applied for two COMMERCIAL connections .");
	  }

	    // Start creating new connection
	    Connection connection = new Connection();
	    connection.setConnectionType(requestedType);
	    connection.setCustomerId(customerId);

	    AddressDto customerAddress = customerFeignClient.getCustomerAddress(customerId);
	    System.out.println("Customer Address: " + customerAddress.getCity() + " " + customerAddress.getDistrict());

	    List<DistributorProfileDTO> distributors = distributorFeignClient.getAllDistributors();
	    System.out.println(distributors.size());

	    DistributorProfileDTO assignedDistributor = null;

	    for (DistributorProfileDTO distributor : distributors) {
	        try {
	            AddressDto distributorAddress = distributorFeignClient.getDistributorAddress(distributor.getId());

	            System.out.println(distributor.getId());
	            System.out.println("Distributor Address: " + distributorAddress.getCity() + " " + distributorAddress.getDistrict());

	            if (distributorAddress.getCity().equalsIgnoreCase(customerAddress.getCity()) &&
	                distributorAddress.getDistrict().equalsIgnoreCase(customerAddress.getDistrict())) {
	                assignedDistributor = distributor;
	                break;
	            }
	        } catch (Exception e) {
	            System.out.println("Error fetching address for distributor Id: " + distributor.getId());
	            System.out.println("Exception message: " + e.getMessage());
	        }
	    }

	    if (assignedDistributor == null) {
	        throw new ResourceNotFoundException("No distributor available in the same area as the customer.");
	    }

	    connection.setDistributorId(assignedDistributor.getId());
	    connection.setConnectionStatus(ConnectionStatus.PENDING);

	    return repository.save(connection);
	}

	
	@Override
	public Connection getConnectionById(Long connectionId) {
		return repository.findById(connectionId).orElse(null);
	}
	

	@Override
	public List<Connection> getConnectionByCustomerId(long customerId) {
		return repository.findByCustomerId(customerId);
	}
	
	@Override
	public List<Connection> getConnectionsHistory(){
		return repository.findAll();
	}
	
	@Override
	public void deleteConnection(Long connectionId) {
		repository.deleteById(connectionId);
	}
	
	@Override
	public List<Connection> pendingConnections(){
		return repository.findAll().stream().filter(a->a.getConnectionStatus()==ConnectionStatus.PENDING).toList();
	}
	
	@Override
	public List<Connection> allApprovedConnections(){
		return repository.findAll().stream().filter(a->a.getConnectionStatus()==ConnectionStatus.APPROVED).toList();
	}
	
	@Override
	public Connection approveConnection(long connectionId) {
		Connection connection= repository.findById(connectionId).orElseThrow(() ->new ResourceNotFoundException("Connection with given ID is not availabe"));
		System.out.println(connection);
		connection.setConnectionStatus(ConnectionStatus.APPROVED);
		CustomerProfile customerProfile = customerFeignClient.getCustomerProfile(connection.getCustomerId());
		
        EmailRequest emailRequest = new EmailRequest();
		
		Map<String, Object> properties = new HashMap<>();
		properties.put("message", "Your Connection ("+connectionId+") has been approved.");
		properties.put("fullName", customerProfile.getUsername());
		emailRequest.setTo(customerProfile.getUsername());
		emailRequest.setSubject("Connection Approved");
		emailRequest.setProperties(properties);
		
		emailFeignClient.sendMail(emailRequest);
	
		
		connection.setApprovedDate(LocalDate.now());
		
		return repository.save(connection);
		
	}
	
	@Override
	public Connection rejectConnection(long connectionId) {
		Connection connection= repository.findById(connectionId).orElseThrow(() ->new ResourceNotFoundException("Connection with given ID is not availabe"));
		System.out.println(connection);
		connection.setConnectionStatus(ConnectionStatus.REJECTED);
		
		return repository.save(connection);
		
	}

}

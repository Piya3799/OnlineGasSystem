package com.connection.feign;

import org.springframework.cloud.openfeign.FeignClient;



import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import com.connection.dto.AddressDto;
import com.connection.dto.DistributorProfileDTO;

import java.util.List;


@FeignClient(name = "authentication-service",url="http://localhost:8081")
public interface DistributorFeignClient {
    
    @GetMapping("/api/internal/distributor/all")
    List<DistributorProfileDTO> getAllDistributors();

    @GetMapping("/api/internal/distributor/address/{id}")
    AddressDto getDistributorAddress(@PathVariable("id") Long distributorId);
        

}

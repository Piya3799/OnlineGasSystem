package com.connection.dto;

import lombok.Data;

@Data
public class AddressDto {
    private Long id;
    private String addressLine;
    private String city;
    private String district;
    private String state;
    private String pincode;
}
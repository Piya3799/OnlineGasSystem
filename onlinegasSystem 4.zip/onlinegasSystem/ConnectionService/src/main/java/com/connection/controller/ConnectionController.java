package com.connection.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.connection.dto.ConnectionDTO;
import com.connection.entity.Connection;
import com.connection.service.ConnectionService;

@RestController
@RequestMapping("/connections")
public class ConnectionController {
	
	@Autowired
	private ConnectionService connectionService;
	
	@PostMapping("/create")
	public ResponseEntity<Connection> createConnection(
			@RequestHeader("X-Authenticated-id") String id,
	        @RequestBody ConnectionDTO connectionDTO) {

         long customerId = Long.parseLong(id);
	    Connection connection = connectionService.createConnection(connectionDTO, customerId);
	    return ResponseEntity.ok(connection);
	}
	
	@GetMapping("/{connectionId}")  
	public Connection getConnectionById(@PathVariable Long connectionId) {
		return connectionService.getConnectionById(connectionId);
	}
	
	@GetMapping   //admin
	public List<Connection> getConnectionsHistory(){
		return connectionService.getConnectionsHistory();
	}
		
	@DeleteMapping("/{connectionId}") //admin
	public void deleteConnection(@PathVariable Long connectionId) {
		connectionService.deleteConnection(connectionId);
	}
	
	@GetMapping("/customer/{customerId}")
	public List<Connection> getConnectionByCustomerId(@PathVariable Long customerId) {
		return connectionService.getConnectionByCustomerId(customerId);
	}
	
	@GetMapping("/pendingConnections") //admin
	public ResponseEntity<?> getPendingConnection(){
		List<Connection> pendingList= connectionService.pendingConnections();
		if(pendingList.isEmpty()) {
			return new ResponseEntity<>("No pending Connection is available",HttpStatus.OK);
		}
		else {
		return new ResponseEntity<>(connectionService.pendingConnections(),HttpStatus.OK);}
	}
	
	@GetMapping("/allApprovedConnections")  //admin
	public ResponseEntity<?> getAllApprovedConnections(){
		List<Connection> approvedList= connectionService.allApprovedConnections();
		if(approvedList.isEmpty()) {
			return new ResponseEntity<>("No approved Connection is available",HttpStatus.OK);
		}
		else {
		return new ResponseEntity<>(connectionService.allApprovedConnections(),HttpStatus.OK);}
	}
	
	@PutMapping("/approveConnection/{connectionId}") //admin
	public Connection ApproveConnection(@PathVariable long connectionId) {
		return connectionService.approveConnection(connectionId);
	}
	
	@PutMapping("/rejectConnection/{connectionId}") //admin
	public Connection rejectConnection(@PathVariable long connectionId) {
		return connectionService.rejectConnection(connectionId);
	}

}

package com.connection.dto;

import lombok.Data;

@Data
public class CustomerProfile {
    private Long id;
    private String username;
    private String fullName;
    private String phoneNumber;
    private String gender;
    private String dateOfBirth;
    private AddressDto address; 
}

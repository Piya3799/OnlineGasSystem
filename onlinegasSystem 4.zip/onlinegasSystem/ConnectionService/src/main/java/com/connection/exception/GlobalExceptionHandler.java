package com.connection.exception;
 
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
 
 
@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> validationHandler(MethodArgumentNotValidException e){
		Map<String, String> errors = new HashMap<String, String>();
		List<FieldError> error = e.getBindingResult().getFieldErrors();
		for(FieldError f: error) {
			errors.put(f.getField(), f.getDefaultMessage());
		}
		return new ResponseEntity<Map<String,String>>(errors, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<String> handleInvalidInput(HttpMessageNotReadableException ex){
		if(ex.getCause() instanceof InvalidFormatException formatEx) {
			Class<?> targetType = formatEx.getTargetType();
			
			if(targetType.isEnum()) {
				Object[] validValues= targetType.getEnumConstants();
				String fieldName=formatEx.getPath().get(0).getFieldName();
				return new ResponseEntity<>(fieldName+" must be one of: "+Arrays.toString(validValues),HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<>("Invalid request format",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<String> globalExceptionHandler(ResourceNotFoundException e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
	}
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> allExceptionHandler(Exception e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
	}
}
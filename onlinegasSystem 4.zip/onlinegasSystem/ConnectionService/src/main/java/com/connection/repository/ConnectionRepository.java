
package com.connection.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.connection.entity.Connection;

public interface ConnectionRepository extends JpaRepository<Connection, Long> {
	
	List<Connection> findByCustomerId(long customerId);

}

package com.connection.enums;

public enum ConnectionStatus {
	
	PENDING,
	APPROVED,
	REJECTED

}

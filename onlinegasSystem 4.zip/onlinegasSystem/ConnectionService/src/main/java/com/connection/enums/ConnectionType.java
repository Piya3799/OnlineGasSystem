package com.connection.enums;

public enum ConnectionType {
	DOMESTIC,
	COMMERCIAL;

}

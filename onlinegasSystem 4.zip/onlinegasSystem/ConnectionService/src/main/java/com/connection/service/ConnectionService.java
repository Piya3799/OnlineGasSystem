package com.connection.service;

import java.util.List;

import com.connection.dto.ConnectionDTO;
import com.connection.entity.Connection;

public interface ConnectionService {

	Connection createConnection(ConnectionDTO connectionDTO, long customerId);

	Connection getConnectionById(Long connectionId);

	List<Connection> getConnectionsHistory();

	void deleteConnection(Long connectionId);

	List<Connection> pendingConnections();

	Connection approveConnection(long connectionId);

	Connection rejectConnection(long connectionId);

	List<Connection> getConnectionByCustomerId(long customerId);

	List<Connection> allApprovedConnections();

}

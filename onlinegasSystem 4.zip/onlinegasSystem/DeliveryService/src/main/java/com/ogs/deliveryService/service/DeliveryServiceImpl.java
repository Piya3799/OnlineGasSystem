package com.ogs.deliveryService.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ogs.deliveryService.Exception.DeliveryNotFoundException;
import com.ogs.deliveryService.Exception.InvalidOTPException;
import com.ogs.deliveryService.dto.DeliveryRequest;
import com.ogs.deliveryService.dto.DeliveryResponse;
import com.ogs.deliveryService.entity.Delivery;
import com.ogs.deliveryService.entity.DeliveryStatus;
import com.ogs.deliveryService.repository.DeliveryRepository;


@Service
public class DeliveryServiceImpl implements DeliveryService {

	@Autowired
	private DeliveryRepository deliveryRepo;
	
	@Override
    public DeliveryResponse assignDeliveryDate(DeliveryRequest deliveryrequest){
		
        Delivery delivery = new Delivery();
        delivery.setBookingId(deliveryrequest.getBookingId());
        delivery.setCustomerId(deliveryrequest.getCustomerId());
        delivery.setDistributorId(deliveryrequest.getDistributorId());
        delivery.setDeliveryDate(LocalDate.now().plusDays(2));
        delivery.setAssignedDate(LocalDate.now());
        delivery.setStatus(DeliveryStatus.PENDING);
        delivery.setOtp(generateOTP());
       
        Delivery savedDelivery = deliveryRepo.save(delivery);

        return new DeliveryResponse(
        		savedDelivery.getDeliveryId(),
        		savedDelivery.getStatus().name(), 
        		"Delivery assigned successfully",
        		savedDelivery.getDeliveryDate());
    }
	
	

	@Override
	public Delivery getDeliveryById(Long deliveryId) {
		return deliveryRepo.findById(deliveryId)
				.orElseThrow(() -> new DeliveryNotFoundException("Delivery not found for ID: " + deliveryId));
		
	}
	
	
    @Override
    public List<Delivery> getDeliveriesByCustomer(Long customerId) {
        return deliveryRepo.findByCustomerId(customerId);
    }

    @Override
    public List<Delivery> getDeliveriesByDistributor(Long distributorId) {
        return deliveryRepo.findByDistributorId(distributorId);
    }

    @Override
    public Delivery markAsDelivered(Long deliveryId, String otp) {
        Delivery delivery = deliveryRepo.findById(deliveryId)
            .orElseThrow(() ->new DeliveryNotFoundException("Delivery not found for ID: " + deliveryId)); 
        
        if (delivery.getStatus() == DeliveryStatus.CANCELLED) {
            throw new IllegalStateException("Cannot mark as delivered: delivery has been cancelled.");
        }

        System.out.println("Stored OTP: " + delivery.getOtp());
        System.out.println("Entered OTP: " + otp);
        
        if (String.valueOf(delivery.getOtp()).equals(otp)) {
            delivery.setStatus(DeliveryStatus.DELIVERED);
        } else {
            throw new InvalidOTPException("Invalid OTP entered for delivery ID: " +deliveryId);
        }
        return deliveryRepo.save(delivery);
    }

    private String generateOTP() {
        return String.valueOf((int)(Math.random() * 9000) + 1000);
    }
    
    @Override
    public List<Delivery> getDeliveriesByStatus(DeliveryStatus status) {
        return deliveryRepo.findByStatus(status);
    }

    
    @Scheduled(cron = "0 */15 * * * *")
    @Transactional
    public void checkAndUpdateDeliveryStatus() {
        List<Delivery> pendingDeliveries = deliveryRepo.findByStatus(DeliveryStatus.PENDING);
        for (Delivery delivery : pendingDeliveries) {
        	 if (delivery.getStatus() != DeliveryStatus.CANCELLED && shouldBeOutForDelivery(delivery)) {
                 delivery.setStatus(DeliveryStatus.OUT_FOR_DELIVERY);
                 deliveryRepo.save(delivery);
             }

        }
    }
    
    private boolean shouldBeOutForDelivery(Delivery delivery) {
       
        boolean isDeliveryDateToday = LocalDate.now().equals(delivery.getDeliveryDate());
        return isDeliveryDateToday;
    }



	@Override
	public List<Delivery> getAllDeliveries() {
		List<Delivery> AllDeliveries = deliveryRepo.findAll();
		return AllDeliveries;
	}
	
	
	//if booking is cancle update delivcery status as cancle
	@Override
	public Delivery updateDeliveryStatusByBookingId(Long bookingId) {
	    Delivery delivery = deliveryRepo.findByBookingId(bookingId)
	        .orElseThrow(() -> new DeliveryNotFoundException("No delivery found for booking ID: " + bookingId));
	    System.out.println("Received request to update delivery status for booking ID: " + bookingId);
	    delivery.setStatus(DeliveryStatus.CANCELLED);
	    return deliveryRepo.save(delivery);
	}



	
}

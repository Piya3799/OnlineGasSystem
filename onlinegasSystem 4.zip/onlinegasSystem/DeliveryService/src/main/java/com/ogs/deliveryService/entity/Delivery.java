package com.ogs.deliveryService.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "deliveries")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delivery {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long deliveryId;
	    
	    @NotNull(message = "Booking ID cannot be null")
        private Long bookingId;
	    
	    @NotNull(message = "Customer ID cannot be null")
	    private Long customerId;
	    
	    @NotNull(message = "Distributor ID cannot be null")
	    private Long distributorId;
	    
	    @Enumerated(EnumType.STRING)
	    @Column(name = "status")
	    @NotNull(message = "Delivery status is required")
        private DeliveryStatus status;

	    @PastOrPresent(message = "Assigned date cannot be in the future")
	    private LocalDate assignedDate;
	    
	    @NotNull(message = "Delivery date is required")
	    private LocalDate deliveryDate;
	    
	    @Size(min = 4, max = 4, message = "OTP must be exactly 4 digits")
        private String otp;
}


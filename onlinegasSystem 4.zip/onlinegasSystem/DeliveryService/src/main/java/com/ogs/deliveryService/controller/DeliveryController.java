package com.ogs.deliveryService.controller;

	
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ogs.deliveryService.dto.DeliveryRequest;
import com.ogs.deliveryService.dto.DeliveryResponse;
import com.ogs.deliveryService.entity.Delivery;
import com.ogs.deliveryService.entity.DeliveryStatus;
import com.ogs.deliveryService.service.DeliveryService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/delivery")
@RequiredArgsConstructor
public class DeliveryController {

	    @Autowired
	    private  DeliveryService deliveryService;

	    @PostMapping("/assign")
	    public ResponseEntity<DeliveryResponse> assignDelivery( @Valid @RequestBody DeliveryRequest deliveryrequest) {
	        DeliveryResponse delivery = deliveryService.assignDeliveryDate(deliveryrequest);
	        return ResponseEntity.ok(delivery);
	    }
	    
	    @GetMapping("/all")
	    public ResponseEntity<List<Delivery>> getAllDeliveries(){
	    	return ResponseEntity.ok(deliveryService.getAllDeliveries());
	    }

    
	    @GetMapping("/{deliveryId}") //admin  
	    public ResponseEntity<Delivery> getDeliveryById(@PathVariable Long deliveryId){
	    	return ResponseEntity.ok(deliveryService.getDeliveryById(deliveryId));
	    }

	    @GetMapping("/customer") //customer
	    public ResponseEntity<List<Delivery>> getDeliveriesByCustomer( @RequestHeader("X-Authenticated-id") String authenticatedId)
	   {
	    	Long customerId=Long.parseLong(authenticatedId);
	        return ResponseEntity.ok(deliveryService.getDeliveriesByCustomer(customerId));
	    }

	    @GetMapping("/distributor") //Distributor
	    public ResponseEntity<List<Delivery>> getDeliveriesByDistributor(@RequestHeader("X-Authenticated-id") String authenticatedId) {
	    	long distributorId = Long.parseLong(authenticatedId);
	        return ResponseEntity.ok(deliveryService.getDeliveriesByDistributor(distributorId));
	    }

	    @PostMapping("/mark-delivered/{deliveryId}") //distributor
	    public ResponseEntity<Delivery> markDelivered(@PathVariable Long deliveryId, @RequestParam String otp) {
	        return ResponseEntity.ok(deliveryService.markAsDelivered(deliveryId, otp));
	    }
	    
	    @GetMapping("/status/{status}") // Fetch deliveries based on status //distibutor admin
	    public ResponseEntity<List<Delivery>> getDeliveriesByStatus(@PathVariable DeliveryStatus status) {
	        return ResponseEntity.ok(deliveryService.getDeliveriesByStatus(status));
	    } 
	    
	    @PutMapping("/update-status") // Allows manual execution
	    public ResponseEntity<String> updateDeliveryStatus() {
	        deliveryService.checkAndUpdateDeliveryStatus();
	        return ResponseEntity.ok("Delivery statuses updated successfully.");
	    }
	    
	    
	    @PutMapping("/booking/{bookingId}/Cancel")
	    public ResponseEntity<Delivery> updateStatusByBookingId(
	            @PathVariable Long bookingId) {
	        Delivery updated = deliveryService.updateDeliveryStatusByBookingId(bookingId);
	        return ResponseEntity.ok(updated);
	    }

}

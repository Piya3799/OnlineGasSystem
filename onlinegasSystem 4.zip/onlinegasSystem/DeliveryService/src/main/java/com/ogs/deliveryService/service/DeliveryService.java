package com.ogs.deliveryService.service;

import java.util.List;

import com.ogs.deliveryService.dto.DeliveryRequest;
import com.ogs.deliveryService.dto.DeliveryResponse;
import com.ogs.deliveryService.entity.Delivery;
import com.ogs.deliveryService.entity.DeliveryStatus;

public interface DeliveryService {
	
	 DeliveryResponse assignDeliveryDate(DeliveryRequest deliveryRequest);
	 Delivery getDeliveryById(Long deliveryId);
	 List<Delivery> getDeliveriesByCustomer(Long customerId);
     List<Delivery> getDeliveriesByDistributor(Long distributorId);
     Delivery markAsDelivered(Long deliveryId, String otp);
     List<Delivery> getDeliveriesByStatus(DeliveryStatus status);
     List<Delivery> getAllDeliveries();
     void checkAndUpdateDeliveryStatus();
     
     Delivery updateDeliveryStatusByBookingId(Long bookingId);


}

package com.ogs.deliveryService.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class DeliveryRequest {

	 private Long bookingId;
	 private Long customerId;
	 private Long distributorId;
	 
}

package com.ogs.deliveryService.entity;

public enum DeliveryStatus {
	PENDING,
	OUT_FOR_DELIVERY,
	DELIVERED,
	FAILED

}

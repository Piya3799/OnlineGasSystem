package com.ogs.deliveryService.dto;




import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeliveryResponse {
	private Long deliveryId;
    private String status;
    private String message;
    private LocalDate deliveryDate;

}

package com.ogs.deliveryService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ogs.deliveryService.entity.Delivery;
import com.ogs.deliveryService.entity.DeliveryStatus;

@Repository
public interface DeliveryRepository extends JpaRepository<Delivery, Long> {
    List<Delivery> findByDistributorId(Long distributorId);
    List<Delivery> findByCustomerId(Long customerId);
    List<Delivery> findByStatus(DeliveryStatus status);

}

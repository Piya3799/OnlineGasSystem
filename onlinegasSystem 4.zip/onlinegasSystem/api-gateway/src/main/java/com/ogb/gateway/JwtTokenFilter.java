package com.ogb.gateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@Component
public class JwtTokenFilter extends AbstractGatewayFilterFactory<JwtTokenFilter.GatewayConfig> {

	@Autowired
	RouteValidator routeValidator;
	@Autowired
	JwtService jwtService;

	public JwtTokenFilter() {
		super(GatewayConfig.class);
	}

	@Override
	public GatewayFilter apply(GatewayConfig config) {
		return (exchange, chain) -> {

			ServerHttpRequest request = exchange.getRequest();
			 String auth = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
		        
			Integer id = 0;
			String idString="";
			
			if (routeValidator.isSecured.test(request)) {

				String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

				if (authHeader == null || !authHeader.startsWith("Bearer ")) {
					exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
					return exchange.getResponse().setComplete();
				}

				String token = authHeader.substring(7);
				System.out.println("Incoming token =" +token);

				if (!jwtService.isTokenValid(token)) {
					exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
					return exchange.getResponse().setComplete();
				}

				String role = jwtService.extractClaims(token, claims -> claims.get("role", String.class));
                id = jwtService.extractClaims(token, claims -> claims.get("id", Integer.class));
                idString = String.valueOf(id);

                		
				if (!routeValidator.isAuthorized.test(request, role)) {
					exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
					return exchange.getResponse().setComplete();
				}

			}
			
			ServerHttpRequest modifiedRequest = request.mutate()
				    .header("X-Authenticated-id", idString)
				    .build();

			return chain.filter(exchange.mutate().request(modifiedRequest).build());
	};

	}

	public static class GatewayConfig {
	}
}

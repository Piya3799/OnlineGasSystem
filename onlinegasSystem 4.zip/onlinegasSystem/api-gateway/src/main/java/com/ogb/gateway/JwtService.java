package com.ogb.gateway;

import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

	@Value("${jwt.secret}")
	private String secretString;

	private SecretKey secretKey;

//	public JwtService() {
//		this.secretKey = generateSecretKey();
//	}
//
//	private SecretKey getSecretKey() {
//		return secretKey;
//	}

	private SecretKey generateSecretKey() {
		byte[] keyBytes = Decoders.BASE64.decode(secretString);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	<T> T extractClaims(String token, Function<Claims, T> resolver) {
		Claims claims = extractAllClaims(token);
		return resolver.apply(claims);
	}
	
	
	private Claims extractAllClaims(String token) {
	    try {
	        return Jwts.parserBuilder()
	                   .setSigningKey(generateSecretKey())
	                   .build()
	                   .parseClaimsJws(token)
	                   .getBody();
	    } catch (ExpiredJwtException e) {
	        throw new RuntimeException("Token expired: " + e.getMessage());
	    } catch (JwtException | IllegalArgumentException e) {
	        System.out.println("Malformed token input: " + token);
	        throw new RuntimeException("Invalid token: " + e.getMessage());
	    }
	}


	public boolean isTokenValid(String token) {
		return !isTokenExpired(token); // Negate the result
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		return extractClaims(token, Claims::getExpiration);
	}

}
package com.ogb.gateway;

import java.time.LocalDateTime;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.result.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected Mono<ResponseEntity<Object>> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatusCode status, ServerWebExchange exchange) {

		ErrorResponse<String> errorResponse = new ErrorResponse<String>(String.valueOf(status.value()), ex.getMessage(),
				HttpStatus.valueOf(status.value()).name(), LocalDateTime.now());

		return super.handleExceptionInternal(ex, errorResponse, headers, status, exchange);
	}

	@ExceptionHandler(Exception.class)
	private ResponseEntity<ErrorResponse<String>> handleException(Exception e) {

		ErrorResponse<String> errorResponse = new ErrorResponse<String>(
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR.name(), LocalDateTime.now());

		return new ResponseEntity<ErrorResponse<String>>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
package com.ogb.gateway;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@Component
public class RouteValidator {

	/* ---------- 1. PUBLIC ENDPOINTS (no JWT needed) ---------- */
		public static final List<String> OPEN_API_ENDPOINTS = List.of("/api/auth", "/api/auth/register", "/api/auth/email",
				"/api/auth/forgot-password", "/swagger-ui", "/v3/api-docs", "/eureka", "/api/internal/**");
	 
		public BiPredicate<ServerHttpRequest, String> isAuthorized = (request, role) -> {
	 
			String path = request.getURI().getPath();
			HttpMethod method = request.getMethod();
	 
			/* Customer endpoints */
			if (path.startsWith("/api/customers")) {
	 
				// Self-profile: accessible to CUSTOMER and ADMIN
				if ((method == HttpMethod.GET || method == HttpMethod.POST || method == HttpMethod.PUT)
						&& path.equals("/api/customers/profile")) {
					return role.equals("CUSTOMER") || role.equals("ADMIN");
				}
	 
				// Admin-only: view all or any customer by ID
				if (method == HttpMethod.GET && (path.equals("/api/customers") || path.matches("/api/customers/\\d+"))) {
					return role.equals("ADMIN");
				}
	 
				// Address operations (GET/POST/PUT/DELETE): only CUSTOMER
				if (path.equals("/api/customers/address")) {
					return role.equals("CUSTOMER");
				}
			}
	 
			/* Distributor endpoints */
			if (path.startsWith("/api/distributor")) {
	 
				// Self-profile: accessible to DISTRIBUTOR and ADMIN
				if ((method == HttpMethod.GET || method == HttpMethod.POST || method == HttpMethod.PUT)
						&& path.equals("/api/distributor/profile")) {
					return role.equals("DISTRIBUTOR") || role.equals("ADMIN");
				}
	 
				// Admin-only: view all or any distributor by ID
				if (method == HttpMethod.GET
						&& (path.equals("/api/distributor") || path.matches("/api/distributor/\\d+"))) {
					return role.equals("ADMIN") || role.equals("CUSTOMER");
				}
				// Address operations (GET/POST/PUT/DELETE): only DISTRIBUTOR
				if (path.equals("/api/distributor/address")) {
					return role.equals("DISTRIBUTOR") || role.equals("CUSTOMER");
				}
			}
	 
			/* Booking end points */
			if (path.startsWith("/api/booking")) {
	 
				if (HttpMethod.POST.equals(method) && path.equals("/api/booking/create")) {
					return role.equals("CUSTOMER");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/booking/customer")
	 
						|| path.matches("/api/booking/get/\\d+")) {
					return role.equals("CUSTOMER");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/booking/distributor")) {
					return role.equals("DISTRIBUTOR");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/booking/get/\\d+")
						|| path.matches("/api/booking/all") || HttpMethod.DELETE.equals(method)) {
					return role.equals("ADMIN") || role.equals("CUSTOMER");
				}
	 
				return true;
			}
	 
			if (path.startsWith("/api/delivery")) {
				if (HttpMethod.POST.equals(method) && path.equals("/api/delivery/assign")) {
					return role.equals("CUSTOMER");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/delivery/customer")) {
					return role.equals("CUSTOMER");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/delivery/distributor")) {
					return role.equals("DISTRIBUTOR");
				} else if (HttpMethod.POST.equals(method) && path.matches("/api/delivery/mark-delivered/\\d+")) {
					return role.equals("DISTRIBUTOR");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/delivery/status/\\w+")) {
					
					
					return role.equals("ADMIN") || role.equals("DISTRIBUTOR");
				} else if (HttpMethod.GET.equals(method) && path.matches("/api/delivery/\\d+")) {
					return role.equals("ADMIN");
				}else if (HttpMethod.GET.equals(method) && path.equals("/api/delivery/all")) {
				    return role.equals("ADMIN");
				}

				else if (HttpMethod.PUT.equals(method) && path.equals("/api/delivery/update-status")) {
					return role.equals("ADMIN");
				}
			}
			
			/* Connection endpoints */
			if (path.startsWith("/connections")) {
	 
				// CUSTOMER: Create connection
				if (HttpMethod.POST.equals(method) && path.equals("/connections/create")) {
					return role.equals("CUSTOMER");
				}
				// CUSTOMER: Get own connection by ID
				if (HttpMethod.GET.equals(method) && path.matches("/connections/\\d+")) {
					return role.equals("CUSTOMER") || role.equals("ADMIN");
				}
				if (HttpMethod.GET.equals(method) && path.matches("/connections/customer/\\d+")) {
					return role.equals("CUSTOMER") || role.equals("ADMIN");
				}
				if (HttpMethod.PUT.equals(method) && path.matches("/connections/approveConnection/\\d+")) {
					return role.equals("ADMIN");
				}
				if (HttpMethod.PUT.equals(method) && path.matches("/connections/rejectConnection/\\d+")) {
					return role.equals("ADMIN");
				}
				// ADMIN: Get all connections, update any, delete any
				if ((HttpMethod.GET.equals(method) || path.matches("/connections")) || HttpMethod.PUT.equals(method)
						|| HttpMethod.DELETE.equals(method)) {
					return role.equals("ADMIN");
				}
			}
	 
			if (path.startsWith("/payments") || path.startsWith("/product/v1/checkout") || path.startsWith("/stripe")) {
//				if (HttpMethod.POST.equals(method) && path.equals("/product/v1/checkout") && path.matches("/stripe/verify/\\w+")) {
//					return role.equals("CUSTOMER");}
//				} else if (HttpMethod.GET.equals(method) && path.matches("/stripe/verify/\\w+")) {
//					return role.equals("ADMIN");
//				} else if (HttpMethod.GET.equals(method) || HttpMethod.PUT.equals(method)
//						|| HttpMethod.DELETE.equals(method)) {
//					return role.equals("ADMIN") || role.equals("DISTRIBUTOR");
//				}
				return true;
			}
	 
			return false;
		};
	 
		/* ---------- 3. SECURED-ROUTE CHECK (token required) ---------- */
		public Predicate<ServerHttpRequest> isSecured = request -> OPEN_API_ENDPOINTS.stream()
				.noneMatch(uri -> request.getURI().getPath().startsWith(uri));

}
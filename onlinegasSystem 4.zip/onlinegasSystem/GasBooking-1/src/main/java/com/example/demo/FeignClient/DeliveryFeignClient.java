package com.example.demo.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.Delivery;
import com.example.demo.dto.DeliveryRequest;
import com.example.demo.enums.DeliveryStatus;


@FeignClient(name="DeliveryService", url = "http://localhost:8086/api/delivery")
public interface DeliveryFeignClient {
	
	@PostMapping("/assign")
    ResponseEntity<Delivery> assignDelivery( @RequestBody DeliveryRequest request );

	
	@PutMapping("/booking/{bookingId}/Cancel")
    Delivery updateDeliveryStatus(@PathVariable("bookingId") Long bookingId);


}
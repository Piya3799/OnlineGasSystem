package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients(basePackages = "com.example.demo.FeignClient")
@SpringBootApplication
public class GasBooking1Application {

	public static void main(String[] args) {
		SpringApplication.run(GasBooking1Application.class, args);
	}

}

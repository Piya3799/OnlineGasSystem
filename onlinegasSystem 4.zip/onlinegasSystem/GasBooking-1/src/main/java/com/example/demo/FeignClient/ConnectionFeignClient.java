package com.example.demo.FeignClient;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.dto.ConnectionResponseDTO;

@FeignClient(name = "ConnectionService", url = "http://localhost:8083")
public interface ConnectionFeignClient {
    
    @GetMapping("/connections/{connectionId}")
    ConnectionResponseDTO getConnectionById(@PathVariable Long connectionId);
}

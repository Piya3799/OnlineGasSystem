package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.BookingService;
import com.example.demo.dto.BookingDTO;
import com.example.demo.entity.Booking;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/booking")
public class BookingController {

	@Autowired     
	private BookingService bookingservice; 
	 
    @PostMapping("/create")   //customer  
    public Booking createBooking(@Valid @RequestBody BookingDTO bookingdto)
    {        
    	return bookingservice.createBooking(bookingdto); 
    } 
 
    @DeleteMapping("/cancel/{bookingId}")  //customer  
    public Booking cancelBooking(@PathVariable Long bookingId)
    {        
    	return bookingservice.cancelBooking(bookingId); 
    } 
    
    @GetMapping("/get/{bookingId}") //admin
    public ResponseEntity<Booking> getBookingById(@PathVariable("bookingId") Long bookingId) {
        Booking booking = bookingservice.getBookingById(bookingId);
        return ResponseEntity.ok(booking);
    }

 
    @GetMapping("/customer")  //customer   
    public List<Booking> getCustomerBookings( @RequestHeader("X-Authenticated-id") String authenticatedId) 
    {   
    	 Long customerId = Long.parseLong(authenticatedId);
    	return bookingservice.getCustomerBookings(customerId); 
    } 
 
    @GetMapping("/distributor")  //distributor
    public List<Booking> getDistributorBookings( @RequestHeader("X-Authenticated-id") String authenticatedId)
    {    
    	Long distributorId = Long.parseLong(authenticatedId);
    	return bookingservice.getDistributorBookings(distributorId); 
    } 
 
    @GetMapping("/all")   //admin 
    public List<Booking> getAllBookings() 
    {       
    	return bookingservice.getAllBookings(); 
    } 

}

package com.example.demo.enums;

public enum DeliveryStatus {
	
	PENDING,
	OUT_FOR_DELIVERY,
	DELIVERED,
	CANCELLED

}

package com.example.demo.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dto.BookingDTO;
import com.example.demo.entity.Booking;

public interface BookingService {
	Booking createBooking(BookingDTO bookingdto); 
    Booking cancelBooking(Long bookingId); 
    Booking getBookingById(Long bookingdto);     
    List<Booking> getAllBookings(); 
    List<Booking> getCustomerBookings(Long customerId); 
    List<Booking> getDistributorBookings(Long distributorId); 

}

package com.example.demo.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.demo.dto.PaymentRequest;
import com.example.demo.dto.PaymentResponse;

@FeignClient(name = "PaymentService", url = "http://localhost:8082")
public interface PaymentFeignClient {
    @PostMapping("/payments")
    PaymentResponse createPayment(@RequestBody PaymentRequest request);
}
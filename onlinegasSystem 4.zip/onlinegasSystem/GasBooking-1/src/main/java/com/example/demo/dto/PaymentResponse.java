package com.example.demo.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PaymentResponse {
    private Long id;
    private Long bookingId;
    private String status;
    private String transactionId;
    private LocalDateTime paymentDate;
}
package com.example.demo.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.FeignClient.ConnectionFeignClient;
import com.example.demo.FeignClient.DeliveryFeignClient;
import com.example.demo.FeignClient.PaymentFeignClient;
import com.example.demo.dto.BookingDTO;
import com.example.demo.dto.ConnectionResponseDTO;
import com.example.demo.dto.ConnectionResponseDTO.ConnectionStatus;
import com.example.demo.dto.DeliveryRequest;
import com.example.demo.dto.PaymentRequest;
import com.example.demo.dto.PaymentResponse;
import com.example.demo.entity.Booking;
import com.example.demo.enums.DeliveryStatus;
import com.example.demo.repository.BookingRepository;

import feign.FeignException;
import jakarta.annotation.PostConstruct;
import java.math.BigDecimal;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepo;
    
    @Autowired
    private ConnectionFeignClient connectionFeignClient;

    @Autowired
    private DeliveryFeignClient deliveryfeignclient;

    @Autowired
    private PaymentFeignClient paymentFeignClient;

    @PostConstruct
    public void init() {
        System.out.println("DeliveryFeignClient initialized: " + deliveryfeignclient);
        System.out.println("PaymentFeignClient initialized: " + paymentFeignClient);
    }

    @Override
    public Booking createBooking(BookingDTO bookingdto) {
    	
    	ConnectionResponseDTO connection = connectionFeignClient.getConnectionById(bookingdto.getConnectionId());

        // Validate if Connection is Approved
        if (connection == null || connection.getConnectionStatus() != ConnectionStatus.APPROVED) {
            throw new IllegalStateException("Booking cannot be created because the connection is not approved.");
        }

        Booking booking = new Booking();
        booking.setConnectionId(bookingdto.getConnectionId());
        booking.setCustomerId(connection.getCustomerId());
        booking.setDistributorId(connection.getDistributorId());
        booking.setQuantity(bookingdto.getQuantity());
        booking.setBookingDate(LocalDate.now());
        booking.setLastUpdated(LocalDateTime.now());
        booking.setStatus(Booking.BookingStatus.BOOKED);

        Booking savedBooking = bookingRepo.save(booking);

        // Payment integration
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setBookingId(savedBooking.getBookingId());
        paymentRequest.setAmount(BigDecimal.valueOf(savedBooking.getQuantity() * 1200)); 
        paymentRequest.setMethod("CARD");

        //PaymentResponse paymentResponse = paymentFeignClient.createPayment(paymentRequest);

        // Delivery integration
        DeliveryRequest deliveryRequest = new DeliveryRequest(
                savedBooking.getBookingId(),
                savedBooking.getCustomerId(),
                savedBooking.getDistributorId()
        );

        try {
            deliveryfeignclient.assignDelivery(deliveryRequest);
            
        } catch (FeignException e) {
            throw new RuntimeException("Delivery assignment failed: " + e.getMessage());
        }

        return savedBooking;
    }

    @Override
    public Booking getBookingById(Long bookingId) {
        return bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found for ID: " + bookingId));
    }

    @Override
    public Booking cancelBooking(Long bookingId) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        booking.setStatus(Booking.BookingStatus.CANCELLED);
        booking.setLastUpdated(LocalDateTime.now());
       
        Booking cancelledBooking = bookingRepo.save(booking);

       
        try {
            deliveryfeignclient.updateDeliveryStatus(bookingId);
            System.out.println("Calling delivery service to cancel delivery for booking ID: " + bookingId);
        } catch (FeignException e) {
            System.out.println("Failed to update delivery status: " + e.getMessage());
        }

        return cancelledBooking;

    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    @Override
    public List<Booking> getCustomerBookings(Long customerId) {
        return bookingRepo.findByCustomerId(customerId);
    }

    @Override
    public List<Booking> getDistributorBookings(Long distributorId) {
        return bookingRepo.findByDistributorId(distributorId);
    }
}
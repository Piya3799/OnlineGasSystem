package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConnectionResponseDTO {
    private Long connectionId;
    private Long customerId;
    private Long distributorId;
    private ConnectionStatus connectionStatus;
    private LocalDate approvedDate;
    
    public enum ConnectionStatus{
    	PENDING,
    	APPROVED,
    	REJECTED
    }
}

package com.example.demo.dto;

import java.time.LocalDate;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delivery {
	
	    private Long deliveryId;
	    private Long bookingId;
	    private Long customerId;
	    private Long distributorId;
	    private LocalDate assignedDate;
	    private LocalDate deliveryDate;
	    private String otp;
	    
	
}
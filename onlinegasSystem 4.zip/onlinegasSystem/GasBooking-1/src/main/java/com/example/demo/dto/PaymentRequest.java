package com.example.demo.dto;

import java.math.BigDecimal;
import lombok.Data;

@Data
public class PaymentRequest {
    private Long bookingId;
    private BigDecimal amount;
    private String method;
}
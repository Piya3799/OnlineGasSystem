package com.example.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity 
@Table(name = "bookings") 
@Data 
@NoArgsConstructor 
@AllArgsConstructor 
@ToString
public class Booking {

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Long bookingId; 

    @NotNull(message = "Connection ID cannot be null")   
    private Long connectionId;    

    @NotNull(message = "Customer ID cannot be null")    
    private Long customerId;    

    @NotNull(message = "Distributor ID cannot be null") 
    private Long distributorId; 

    @Min(value = 1, message = "Quantity must be at least 1") 
    private int quantity; 

    @Enumerated(EnumType.STRING) 
    @NotNull(message = "Booking status is required") 
    private BookingStatus status; 

    @PastOrPresent(message = "Booking date cannot be in the future") 
    private LocalDate bookingDate;        

    @PastOrPresent(message = "Last updated timestamp cannot be in the future") 
    private LocalDateTime lastUpdated; 

    public enum BookingStatus { 
        BOOKED, CANCELLED, FAILED 
    } 

}
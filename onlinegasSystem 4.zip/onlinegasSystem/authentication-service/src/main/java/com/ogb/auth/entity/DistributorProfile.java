package com.ogb.auth.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "distributor_profiles")
public class DistributorProfile {
    @Id
    private Long id;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private User user;

    @Column(unique = true, nullable = false)
    @NotBlank(message = "Username is mandatory")
    @Email(message = "Invalid email format. ex:example@mail.com")
    private String username;

    @Column(nullable = false)
    @NotBlank(message = "Name is required")
    private String fullName;

    @Column(nullable = false)
    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^[6-9][0-9]{9}$", message = "Phone number must be 10 digits long and start with 6, 7, 8, or 9.")
    private String phoneNumber;

    private LocalDateTime lastUpdatedAt;

    @OneToOne(mappedBy = "distributorProfile",cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("distributor-address")
    private Address address;
}

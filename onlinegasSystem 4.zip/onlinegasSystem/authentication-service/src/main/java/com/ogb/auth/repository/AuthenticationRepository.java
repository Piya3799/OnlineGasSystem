package com.ogb.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogb.auth.entity.User;

public interface AuthenticationRepository extends JpaRepository<User, Long> {

	User findByUsername(String username);
	
	boolean existsById(Long id);
}

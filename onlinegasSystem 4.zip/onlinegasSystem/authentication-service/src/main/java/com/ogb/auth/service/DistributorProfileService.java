package com.ogb.auth.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ogb.auth.dao.AddressDao;
import com.ogb.auth.dao.AuthenticationDao;
import com.ogb.auth.dao.DistributorProfileDao;
import com.ogb.auth.entity.Address;
import com.ogb.auth.entity.DistributorProfile;
import com.ogb.auth.entity.User;
import com.ogb.auth.exception.UserNotFoundException;
import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.response.DistributorProfileDTO;

@Service
public class DistributorProfileService {

    @Autowired
    DistributorProfileDao distributorProfileDao;

    @Autowired
    AuthenticationDao authenticationDao;

    @Autowired
    AddressDao addressDao;

    public ApiResponse<DistributorProfile> addDistributor(DistributorProfile distributorProfile) {
        User existUser = authenticationDao.getUserByUserName(distributorProfile.getUsername());
        if (existUser == null) {
            throw new UserNotFoundException("User not found with email : " + distributorProfile.getUsername(), HttpStatus.BAD_REQUEST);
        }

        distributorProfile.setUser(existUser);
        DistributorProfile savedDistributor = distributorProfileDao.saveDistributor(distributorProfile);
        return new ApiResponse<>("success", "Profile added successfully", savedDistributor, LocalDateTime.now());
    }


    public ApiResponse<DistributorProfile> getDistributorProfileById(Long id) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(id);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + id, HttpStatus.BAD_REQUEST);
        }
        return new ApiResponse<>("success", "Profile found", distributorProfile, LocalDateTime.now());
    }
    
    public List<DistributorProfileDTO> getAllDistributors() {
        List<DistributorProfile> distributors = distributorProfileDao.getAllDistributors();

        return distributors.stream().map(d -> 
            new DistributorProfileDTO(
                d.getId(),
                d.getUsername(),
                d.getFullName(),
                d.getPhoneNumber(),
                d.getAddress() != null ? new AddressDto(
                    d.getAddress().getId(),
                    d.getAddress().getAddressLine(),
                    d.getAddress().getCity(),
                    d.getAddress().getDistrict(),
                    d.getAddress().getState(),
                    d.getAddress().getPincode()) : null
            )
        ).toList();
    }

    public ApiResponse<DistributorProfile> updateDistributorProfile(Long id, DistributorProfile updatingDistributorProfile) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(id);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + id, HttpStatus.BAD_REQUEST);
        }

        if (updatingDistributorProfile.getFullName() != null) {
            distributorProfile.setFullName(updatingDistributorProfile.getFullName());
        }

        if (updatingDistributorProfile.getPhoneNumber() != null) {
            distributorProfile.setPhoneNumber(updatingDistributorProfile.getPhoneNumber());
        }

        distributorProfile.setLastUpdatedAt(LocalDateTime.now());

        DistributorProfile savedDistributor = distributorProfileDao.saveDistributor(distributorProfile);
        return new ApiResponse<>("success", "Profile updated successfully", savedDistributor, LocalDateTime.now());
    }

    public ApiResponse<Address> addNewAddress(Long distributorId, Address address) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(distributorId);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + distributorId, HttpStatus.BAD_REQUEST);
        }
        address.setDistributorProfile(distributorProfile);
        distributorProfile.setAddress(address);
        distributorProfileDao.saveDistributor(distributorProfile);

        return new ApiResponse<>("success", "Address added successfully", distributorProfile.getAddress(), LocalDateTime.now());
    }

    public ApiResponse<Address> updateAddress(Long distributorId, Address address) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(distributorId);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + distributorId, HttpStatus.BAD_REQUEST);
        }
        
        Address current = distributorProfile.getAddress();
        if (current == null) {
            throw new UserNotFoundException("No address found for distributor ID: " + distributorId, HttpStatus.BAD_REQUEST);
        }

        if (address.getAddressLine() != null) current.setAddressLine(address.getAddressLine());
        if (address.getCity() != null) current.setCity(address.getCity());
        if (address.getDistrict() != null) current.setDistrict(address.getDistrict());
        if (address.getState() != null) current.setState(address.getState());
        if (address.getPincode() != null) current.setPincode(address.getPincode());


        distributorProfile.setLastUpdatedAt(LocalDateTime.now());

        distributorProfileDao.saveDistributor(distributorProfile);

        return new ApiResponse<>("success", "Address updated successfully", address, LocalDateTime.now());
    }

    public ApiResponse<String> deleteAddress(Long distributorId) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(distributorId);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + distributorId, HttpStatus.BAD_REQUEST);
        }

        if (distributorProfile.getAddress() == null) {
            throw new UserNotFoundException("No address found for distributor with ID: " + distributorId, HttpStatus.BAD_REQUEST);
        }

        addressDao.deleteAddress(distributorProfile.getAddress().getId());
        distributorProfile.setAddress(null);
        distributorProfileDao.saveDistributor(distributorProfile);

        return new ApiResponse<>("success", "Address deleted successfully", null, LocalDateTime.now());
    }

    public AddressDto getDistributorAddress(Long distributorId) {
        DistributorProfile distributorProfile = distributorProfileDao.getDistributorProfileById(distributorId);
        if (distributorProfile == null) {
            throw new UserNotFoundException("Profile not found with ID: " + distributorId, HttpStatus.BAD_REQUEST);
        }

        Address address = distributorProfile.getAddress();
        if (address == null) {
            throw new UserNotFoundException("No address found for distributor ID: " + distributorId, HttpStatus.BAD_REQUEST);
        }

        // Convert Address entity to AddressResponseDTO
        return new AddressDto(address.getId(), address.getAddressLine(), address.getCity(), 
                                      address.getDistrict(), address.getState(), address.getPincode());
    }


	

}
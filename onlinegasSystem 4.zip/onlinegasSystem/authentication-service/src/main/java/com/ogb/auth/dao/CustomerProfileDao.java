package com.ogb.auth.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.ogb.auth.entity.CustomerProfile;
import com.ogb.auth.exception.UserNotFoundException;
import com.ogb.auth.repository.CustomerProfileRepo;

@Repository
public class CustomerProfileDao {

    @Autowired
    CustomerProfileRepo customerProfileRepo;

    public CustomerProfile saveCustomer(CustomerProfile customerProfile) {
        return customerProfileRepo.save(customerProfile);
    }

    public CustomerProfile getCustomerProfileById(Long id) {
        return customerProfileRepo.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Customer profile not found with ID: " + id, HttpStatus.NOT_FOUND));
    }

    public List<CustomerProfile> getAllCustomers() {
        return customerProfileRepo.findAll();
    }
}
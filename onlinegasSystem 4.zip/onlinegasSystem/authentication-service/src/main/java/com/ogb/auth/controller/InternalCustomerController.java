package com.ogb.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ogb.auth.entity.CustomerProfile;
import com.ogb.auth.exception.ResourceNotFoundException;
import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.service.CustomerProfileService;

@RestController
@RequestMapping("api/internal/customer")
public class InternalCustomerController {
	
	@Autowired
	private CustomerProfileService customerProfileService;
	
    @GetMapping("/address/{id}")
    public AddressDto getCustomerAddressInternal(@PathVariable Long id) {
    	return customerProfileService.getCustomerAddress(id);
    }
    
    @GetMapping("/profile/{id}")
    public CustomerProfile getCustomerProfileInternal(@PathVariable Long id) {
    	ApiResponse<CustomerProfile> response = customerProfileService.getCustomerProfileById(id);
    	if(response == null || response.getData() == null) {
    		throw new ResourceNotFoundException("Customer not Found with ID: "+ id);
    	}
    	return  response.getData();

    }

}

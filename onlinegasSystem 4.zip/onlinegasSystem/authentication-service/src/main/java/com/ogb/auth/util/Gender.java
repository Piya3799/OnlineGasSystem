package com.ogb.auth.util;

public enum Gender {
MALE,FEMALE,OTHER
}

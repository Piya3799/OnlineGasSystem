package com.ogb.auth.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ogb.auth.entity.User;
import com.ogb.auth.feign.EmailFeignClient;
import com.ogb.auth.request.EmailRequest;
import com.ogb.auth.util.Role;

@Service
public class EmailFeignClientService {

	@Autowired
	private EmailFeignClient emailFeignClient;

	@Autowired
	private VerificationTokenService verificationTokenService;

	public void sendEmailVerificationMail(User user) {

		EmailRequest emailRequest = new EmailRequest();
		emailRequest.setTo(user.getUsername());
		emailRequest.setSubject("Welcome To Online Gas Booking");
		emailRequest.setTemplate("registration-success");
		try {
			String token = verificationTokenService.generateEmailVerificationUrl(user);
			Map<String, Object> properties = new HashMap<>();
			properties.put("verificationUrl", token);
			properties.put("fullName", user.getRole() == Role.CUSTOMER ? "Customer" : "Distributor");
			emailRequest.setProperties(properties);
			emailFeignClient.sendMail(emailRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendPasswordRestMail(User user) {
		EmailRequest emailRequest = new EmailRequest();
		emailRequest.setTo(user.getUsername());
		emailRequest.setSubject("Reset Password");
		emailRequest.setTemplate("forgot-password");
		try {
			String token = verificationTokenService.generateResetPasswordVerificationUrl(user);
			Map<String, Object> properties = new HashMap<>();
			properties.put("passwordResetUrl", token);
			properties.put("fullName", user.getRole() == Role.CUSTOMER ? "Customer" : "Distributor");
			emailRequest.setProperties(properties);
			emailFeignClient.sendMail(emailRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SendMail(EmailRequest emailRequest) {
		try {
			emailFeignClient.sendMail(emailRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

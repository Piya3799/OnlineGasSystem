package com.ogb.auth.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.FetchType;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "addresses")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Address Line is required")
    private String addressLine;

    @Column(nullable = false)
    @NotBlank(message = "City is required")
    private String city;
    
    @Column(nullable = false)
    @NotBlank(message = "District is required")
    private String district;

    @Column(nullable = false)
    @NotBlank(message = "State is required")
    private String state;

    @Column(nullable = false)
    @NotBlank(message = "Pincode is required")
    private String pincode;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id")
    @JsonBackReference("customer-address")
    private CustomerProfile customerProfile;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "distributor_id") 
    @JsonBackReference("distributor-address")
    private DistributorProfile distributorProfile;
    
    
    public Address(Long id, String addressLine, String city, String district, String state, String pincode) {
        this.id = id;
        this.addressLine = addressLine;
        this.city = city;
        this.district = district;
        this.state = state;
        this.pincode = pincode;
    }
}
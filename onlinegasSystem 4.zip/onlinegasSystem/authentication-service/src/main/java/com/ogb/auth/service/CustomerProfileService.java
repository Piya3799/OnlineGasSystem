package com.ogb.auth.service;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ogb.auth.dao.AddressDao;
import com.ogb.auth.dao.AuthenticationDao;
import com.ogb.auth.dao.CustomerProfileDao;
import com.ogb.auth.entity.Address;
import com.ogb.auth.entity.CustomerProfile;
import com.ogb.auth.entity.User;
import com.ogb.auth.exception.UserNotFoundException;
import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.ApiResponse;

@Service
public class CustomerProfileService {

    @Autowired
    CustomerProfileDao customerProfileDao;

    @Autowired
    AuthenticationDao authenticationDao;

    @Autowired
    AddressDao addressDao;

    public ApiResponse<CustomerProfile> addCustomer(CustomerProfile customerProfile) {
        User existUser = authenticationDao.getUserByUserName(customerProfile.getUsername());

        if (existUser == null) {
            throw new UserNotFoundException("User not found with email : " + customerProfile.getUsername(), HttpStatus.BAD_REQUEST);
        }

        customerProfile.setUser(existUser);
        CustomerProfile savedCustomer = customerProfileDao.saveCustomer(customerProfile);
        return new ApiResponse<>("success", "Profile added successfully", savedCustomer, LocalDateTime.now());
    }
    

    public ApiResponse<CustomerProfile> getCustomerProfileById(Long id) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(id);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + id, HttpStatus.BAD_REQUEST);
        }
        return new ApiResponse<>("success", "Profile found", customerProfile, LocalDateTime.now());
    }

    public ApiResponse<CustomerProfile> updateCustomerProfile(Long id, CustomerProfile updatingCustomerProfile) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(id);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + id, HttpStatus.BAD_REQUEST);
        }

        if (updatingCustomerProfile.getFullName() != null) {
            customerProfile.setFullName(updatingCustomerProfile.getFullName());
        }

        if (updatingCustomerProfile.getPhoneNumber() != null) {
            customerProfile.setPhoneNumber(updatingCustomerProfile.getPhoneNumber());
        }

        if (updatingCustomerProfile.getGender() != null) {
            customerProfile.setGender(updatingCustomerProfile.getGender());
        }

        if (updatingCustomerProfile.getDateOfBirth() != null) {
            customerProfile.setDateOfBirth(updatingCustomerProfile.getDateOfBirth());
        }

        customerProfile.setLastUpdatedAt(LocalDateTime.now());

        CustomerProfile savedCustomer = customerProfileDao.saveCustomer(customerProfile);
        return new ApiResponse<>("success", "Profile updated successfully", savedCustomer, LocalDateTime.now());
    }

    public ApiResponse<List<CustomerProfile>> getAllCustomers() {
        List<CustomerProfile> allCustomers = customerProfileDao.getAllCustomers();
        return new ApiResponse<>("success", "Profiles fetched successfully", allCustomers, LocalDateTime.now());
    }

    public ApiResponse<Address> addNewAddress(Long customerId, Address address) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(customerId);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + customerId, HttpStatus.BAD_REQUEST);
        }

        address.setCustomerProfile(customerProfile);
        customerProfile.setAddress(address);

        customerProfileDao.saveCustomer(customerProfile);


        return new ApiResponse<>("success", "Address added successfully", customerProfile.getAddress(), LocalDateTime.now());
    }

    public ApiResponse<Address> updateAddress(Long customerId, Address address) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(customerId);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + customerId, HttpStatus.BAD_REQUEST);
        }
        
        Address current = customerProfile.getAddress();
        if (current == null) {
            throw new UserNotFoundException("No address found for customer ID: " + customerId, HttpStatus.BAD_REQUEST);
        }

        if (address.getAddressLine() != null) current.setAddressLine(address.getAddressLine());
        if (address.getCity() != null) current.setCity(address.getCity());
        if (address.getDistrict() != null) current.setDistrict(address.getDistrict());
        if (address.getState() != null) current.setState(address.getState());
        if (address.getPincode() != null) current.setPincode(address.getPincode());

        customerProfile.setLastUpdatedAt(LocalDateTime.now());
        customerProfileDao.saveCustomer(customerProfile);

        return new ApiResponse<>("success", "Address updated successfully", address, LocalDateTime.now());
    }

    public ApiResponse<String> deleteAddress(Long customerId) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(customerId);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID : " + customerId, HttpStatus.BAD_REQUEST);
        }
        addressDao.deleteAddress(customerProfile.getAddress().getId());
        customerProfile.setAddress(null);
        customerProfileDao.saveCustomer(customerProfile);

        return new ApiResponse<>("success", "Address deleted successfully", null, LocalDateTime.now());
    }

    public AddressDto getCustomerAddress(Long customerId) {
        CustomerProfile customerProfile = customerProfileDao.getCustomerProfileById(customerId);
        if (customerProfile == null) {
            throw new UserNotFoundException("Profile not found with ID: " + customerId, HttpStatus.BAD_REQUEST);
        }

        Address address = customerProfile.getAddress();
        if (address == null) {
            throw new UserNotFoundException("No address found for customer ID: " + customerId, HttpStatus.BAD_REQUEST);
        }

        // Convert Address entity to AddressResponseDTO
        return new AddressDto(address.getId(), address.getAddressLine(), address.getCity(), 
                                      address.getDistrict(), address.getState(), address.getPincode());
    }

}

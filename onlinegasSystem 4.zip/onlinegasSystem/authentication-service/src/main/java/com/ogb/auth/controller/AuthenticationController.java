package com.ogb.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ogb.auth.entity.User;
import com.ogb.auth.request.ForgotPasswordRequest;
import com.ogb.auth.request.LoginRequest;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.service.AuthenticationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

	@Autowired
	AuthenticationService authenticationService;

	@PostMapping("/login")
	public ResponseEntity<ApiResponse<String>> login(@Valid @RequestBody LoginRequest loginRequest) {
		ApiResponse<String> response = authenticationService.login(loginRequest);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/register")
	public ResponseEntity<ApiResponse<User>> register(@Valid @RequestBody User user) {
		ApiResponse<User> response = authenticationService.register(user);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/email/request")
	public ResponseEntity<String> emailVerificationRequest(@RequestParam Long id) {
		String response = authenticationService.emailVericationRequest(id);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/email/verify")
	public ResponseEntity<String> emailVerification(@RequestParam String token) {
		boolean isVerified = authenticationService.verifyEmail(token);
		String response = isVerified ? "Email verified successfully" : "Email already verified";
		return ResponseEntity.ok(response);
	}

	@GetMapping("forgot-password-request")
	public ResponseEntity<String> forgotPasswordRequest(@RequestParam String email) {
		String response = authenticationService.passwordResetRequest(email);
		return ResponseEntity.ok(response);
	}

	@PutMapping("fotgot-password/verify")
	public ResponseEntity<String> forgotPasswordVerification(@RequestParam String token,
			@Valid @RequestBody ForgotPasswordRequest forgotPasswordRequest) {
		String response = authenticationService.resetPassword(token, forgotPasswordRequest.getNewPassword());
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/isUserExists/{userId}")
	public boolean isUserExists(@PathVariable("userId") Long userId) {
		return authenticationService.isUserExists(userId);
	}

}

package com.ogb.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogb.auth.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

    Address findByCustomerProfileId(Long customerId);

    Address findByDistributorProfileId(Long distributorId);
}
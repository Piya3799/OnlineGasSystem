package com.ogb.auth.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDto {
    private Long id;
    private String addressLine;
    private String city;
    private String district;
    private String state;
    private String pincode;
}

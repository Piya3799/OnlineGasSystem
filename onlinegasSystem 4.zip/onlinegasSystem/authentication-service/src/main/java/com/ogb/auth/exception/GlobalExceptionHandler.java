package com.ogb.auth.exception;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ogb.auth.response.ErrorResponse;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse<List<String>>> handleConstraintViolationException(
			ConstraintViolationException ex) {

		List<String> errors = ex.getConstraintViolations().stream().map(e -> e.getMessage())
				.collect(Collectors.toCollection(LinkedList::new));

		ErrorResponse<List<String>> response = new ErrorResponse<List<String>>(
				String.valueOf(HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST.name(), errors,
				LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<ErrorResponse<String>> handleDataIntegrityViolationException(
			DataIntegrityViolationException ex) {

		String message = "";
		if (ex.getMostSpecificCause().getLocalizedMessage().contains("Duplicate entry"))
			message = "The email address is already in use. Please choose a different email.";
		else {
			message = ex.getMostSpecificCause().getLocalizedMessage();
		}
		ErrorResponse<String> response = new ErrorResponse<String>(String.valueOf(HttpStatus.BAD_REQUEST.value()),
				HttpStatus.BAD_REQUEST.name(), message, LocalDateTime.now());

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		List<String> errors = ex.getFieldErrors().stream().map(e -> e.getDefaultMessage()).collect(Collectors.toList());
		ErrorResponse<List<String>> response = new ErrorResponse<List<String>>(
				String.valueOf(HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST.name(), errors,
				LocalDateTime.now());

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ErrorResponse<String>> handleUsernameNotFoundException(UserNotFoundException ex) {
		ErrorResponse<String> response = new ErrorResponse<String>(String.valueOf(HttpStatus.BAD_REQUEST.value()),
				HttpStatus.BAD_REQUEST.name(), ex.getMessage(), LocalDateTime.now());
		return new ResponseEntity<>(response, ex.getStatus());
	}

	@ExceptionHandler(AddressNotFoundException.class)
	public ResponseEntity<ErrorResponse<String>> handleAddressNotFoundException(AddressNotFoundException ex) {
		ErrorResponse<String> response = new ErrorResponse<String>(String.valueOf(HttpStatus.BAD_REQUEST.value()),
				HttpStatus.BAD_REQUEST.name(), ex.getMessage(), LocalDateTime.now());
		return new ResponseEntity<>(response, ex.getStatus());
	}

	@ExceptionHandler(VerificationTokenExpiryException.class)
	public ResponseEntity<ErrorResponse<String>> handleVerificationTokenExpiryException(
			VerificationTokenExpiryException ex) {
		ErrorResponse<String> response = new ErrorResponse<String>(String.valueOf(HttpStatus.BAD_REQUEST.value()),
				HttpStatus.BAD_REQUEST.name(), ex.getMessage(), LocalDateTime.now());
		return new ResponseEntity<>(response, ex.getStatus());
	}

	@ExceptionHandler(AuthException.class)
	public ResponseEntity<ErrorResponse<String>> handleAuthenticationException(AuthException ex) {

		ErrorResponse<String> response = new ErrorResponse<String>(String.valueOf(HttpStatus.BAD_REQUEST.value()),
				HttpStatus.BAD_REQUEST.name(), ex.getMessage(), LocalDateTime.now());

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse<String>> handleGeneralException(Exception ex) {
		String message = "An unexpected error occurred. Please try again later. ";
		System.out.println(ex.getMessage());
		ErrorResponse<String> response = new ErrorResponse<String>(
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR.name(),
				message, LocalDateTime.now());

		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

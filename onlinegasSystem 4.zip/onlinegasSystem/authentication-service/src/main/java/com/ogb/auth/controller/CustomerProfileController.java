package com.ogb.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ogb.auth.entity.Address;
import com.ogb.auth.entity.CustomerProfile;
import com.ogb.auth.exception.ResourceNotFoundException;
import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.service.CustomerProfileService;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerProfileController {

    @Autowired
    CustomerProfileService customerProfileService;

    // ADMIN: get all customers
    @GetMapping
    public ResponseEntity<ApiResponse<List<CustomerProfile>>> getAllCustomers() {
        ApiResponse<List<CustomerProfile>> response = customerProfileService.getAllCustomers();
        return ResponseEntity.ok(response);
    }

    // Customer: create own profile
    @PostMapping("/profile")
    public ResponseEntity<ApiResponse<CustomerProfile>> addCustomerProfile(@Valid @RequestBody CustomerProfile customerProfile) {
        ApiResponse<CustomerProfile> response = customerProfileService.addCustomer(customerProfile);
        return ResponseEntity.ok(response);
    }

    // ADMIN: view any customer by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CustomerProfile>> getCustomerProfile(@PathVariable Long id) {
        ApiResponse<CustomerProfile> response = customerProfileService.getCustomerProfileById(id);
        return ResponseEntity.ok(response);
    }


    // CUSTOMER: get own profile
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<CustomerProfile>> getOwnProfile(
           @RequestHeader("X-Authenticated-id") String authenticatedId) {
        Long userId = Long.parseLong(authenticatedId);
       ApiResponse<CustomerProfile> response = customerProfileService.getCustomerProfileById(userId);
        return ResponseEntity.ok(response);
    }

   

    // CUSTOMER: update own profile
    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<CustomerProfile>> updateOwnProfile(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @RequestBody CustomerProfile customerProfile) {
        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<CustomerProfile> response = customerProfileService.updateCustomerProfile(userId, customerProfile);
        return ResponseEntity.ok(response);
    }
    

    // CUSTOMER: get own address
    @GetMapping("/address")
    public ResponseEntity<AddressDto> getOwnAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId) {
        Long userId = Long.parseLong(authenticatedId);
        AddressDto response = customerProfileService.getCustomerAddress(userId);
        return ResponseEntity.ok(response);
    }

    // CUSTOMER: add own address
    @PostMapping("/address")
    public ResponseEntity<ApiResponse<Address>> addOwnAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @Valid @RequestBody Address address) {
        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<Address> response = customerProfileService.addNewAddress(userId, address);
        return ResponseEntity.ok(response);
    }

    // CUSTOMER: update own address
    @PutMapping("/address")
    public ResponseEntity<ApiResponse<Address>> updateOwnAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @RequestBody Address address) {
        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<Address> response = customerProfileService.updateAddress(userId, address);
        return ResponseEntity.ok(response);
    }

    // CUSTOMER: delete own address
    @DeleteMapping("/address")
    public ResponseEntity<ApiResponse<String>> deleteOwnAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId) {
        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<String> response = customerProfileService.deleteAddress(userId);
        return ResponseEntity.ok(response);
    }
    

}

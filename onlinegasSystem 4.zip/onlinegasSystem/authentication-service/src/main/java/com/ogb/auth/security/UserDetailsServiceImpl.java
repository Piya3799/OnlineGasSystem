package com.ogb.auth.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ogb.auth.dao.AuthenticationDao;
import com.ogb.auth.entity.User;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	AuthenticationDao authenticationDao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = authenticationDao.getUserByUserName(username);

		if (user == null) {
			throw new UsernameNotFoundException("User not found");
		}
		return new UserDetailsImpl(user);
	}

}
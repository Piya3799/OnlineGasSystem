package com.ogb.auth.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ogb.auth.request.EmailRequest;

@FeignClient(name = "email-service", path = "/api/email")
public interface EmailFeignClient {

	
	@PostMapping
	public String sendMail(@RequestBody EmailRequest emailRequest) ;

}

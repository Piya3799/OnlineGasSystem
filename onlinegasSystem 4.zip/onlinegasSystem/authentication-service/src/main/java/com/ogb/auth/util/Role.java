package com.ogb.auth.util;

public enum Role {

	ADMIN, CUSTOMER, DISTRIBUTOR
}

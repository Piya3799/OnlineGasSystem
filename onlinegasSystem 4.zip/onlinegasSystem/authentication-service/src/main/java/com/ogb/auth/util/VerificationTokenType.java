package com.ogb.auth.util;

public enum VerificationTokenType {

	EMAILTOKEN, FORGOTPASSWORDTOKEN;
}

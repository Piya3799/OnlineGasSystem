package com.ogb.auth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.DistributorProfileDTO;
import com.ogb.auth.service.DistributorProfileService;

@RestController
@RequestMapping("/api/internal/distributor")
public class InternalDistributorController {
	
	@Autowired
	private DistributorProfileService distributorProfileService;
	
	 @GetMapping("/address/{id}")
	    public AddressDto getDistributorAddressInternal(@PathVariable Long id) {
	    	return distributorProfileService.getDistributorAddress(id);
	    }
	    
	    @GetMapping("/all")
	    public List<DistributorProfileDTO> getAllDistributorInternal(){
	    	return distributorProfileService.getAllDistributors();
	    }

}

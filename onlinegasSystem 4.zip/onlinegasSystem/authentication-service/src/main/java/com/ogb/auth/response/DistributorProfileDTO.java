package com.ogb.auth.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DistributorProfileDTO {
    private Long id;
    private String username;
    private String fullName;
    private String phoneNumber;
    private AddressDto address; 
}

package com.ogb.auth.entity;

import java.time.LocalDateTime;

import com.ogb.auth.util.VerificationTokenType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "verification_tokens")
public class VerificationToken {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true)
	private String token;

	
	@Enumerated(EnumType.STRING)
	private VerificationTokenType tokenType;

	private LocalDateTime createdAt;
	private LocalDateTime expiresAt;

	@ManyToOne
	@JoinColumn(name = "userId", nullable = false)
	private User user;
}
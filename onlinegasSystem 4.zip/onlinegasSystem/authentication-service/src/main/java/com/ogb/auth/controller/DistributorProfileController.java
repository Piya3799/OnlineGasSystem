package com.ogb.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import com.ogb.auth.entity.Address;
import com.ogb.auth.entity.DistributorProfile;
import com.ogb.auth.exception.ResourceNotFoundException;
import com.ogb.auth.response.AddressDto;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.response.DistributorProfileDTO;
import com.ogb.auth.service.DistributorProfileService;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/distributor")
public class DistributorProfileController {

    @Autowired
    private DistributorProfileService distributorProfileService;

    // Accessible by ADMIN only — all distributors
    @GetMapping
    public ResponseEntity<List<DistributorProfileDTO>> getAllDistributors() {
        List<DistributorProfileDTO> response = distributorProfileService.getAllDistributors();
        return ResponseEntity.ok(response);
    }

    // Accessible by DISTRIBUTOR to create their profile
    @PostMapping("/profile")
    public ResponseEntity<ApiResponse<DistributorProfile>> addDistributorProfile(@Valid @RequestBody DistributorProfile distributorProfile) {
        ApiResponse<DistributorProfile> response = distributorProfileService.addDistributor(distributorProfile);
        return ResponseEntity.ok(response);
    }

    // Accessible by DISTRIBUTOR to fetch their own profile
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<DistributorProfile>> getMyProfile(
            @RequestHeader("X-Authenticated-id") String authenticatedId) {

        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<DistributorProfile> response = distributorProfileService.getDistributorProfileById(userId);
        return ResponseEntity.ok(response);
    }

    // Accessible by DISTRIBUTOR to update their own profile
    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<DistributorProfile>> updateMyProfile(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @RequestBody DistributorProfile distributorProfile) {

        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<DistributorProfile> response = distributorProfileService.updateDistributorProfile(userId, distributorProfile);
        return ResponseEntity.ok(response);
    }

    // Accessible by ADMIN to get any distributor by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DistributorProfile>> getDistributorById(@PathVariable Long id) {
        ApiResponse<DistributorProfile> response = distributorProfileService.getDistributorProfileById(id);
        return ResponseEntity.ok(response);
    }

    // Address Management
    
    @GetMapping("/address")
    public ResponseEntity<ApiResponse<Address>> getDistributorAddress(
    		@RequestHeader("X-Authenticated-id") String authenticatedId,
            @RequestBody Address address) {
        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<Address> response = distributorProfileService.updateAddress(userId, address);
        return ResponseEntity.ok(response);
    }


    @PostMapping(value = "/address", consumes ={"application/json", "application/json;charset=UTF-8"})
    public ResponseEntity<ApiResponse<Address>> addAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @Valid @RequestBody Address address) {

        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<Address> response = distributorProfileService.addNewAddress(userId, address);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/address")
    public ResponseEntity<ApiResponse<Address>> updateAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId,
            @RequestBody Address address) {

        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<Address> response = distributorProfileService.updateAddress(userId, address);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/address")
    public ResponseEntity<ApiResponse<String>> deleteAddress(
            @RequestHeader("X-Authenticated-id") String authenticatedId) {

        Long userId = Long.parseLong(authenticatedId);
        ApiResponse<String> response = distributorProfileService.deleteAddress(userId);
        return ResponseEntity.ok(response);
    }
    
}
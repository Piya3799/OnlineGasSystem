package com.ogb.auth.service;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ogb.auth.entity.User;
import com.ogb.auth.entity.VerificationToken;
import com.ogb.auth.exception.VerificationTokenExpiryException;
import com.ogb.auth.repository.VerificationTokenRepo;
import com.ogb.auth.util.VerificationTokenType;

@Service
public class VerificationTokenService {

	@Autowired
	VerificationTokenRepo tokenRepo;

	public String generateEmailVerificationUrl(User user) {
		String token = saveVerificationToken(user, VerificationTokenType.EMAILTOKEN);
		return "http://localhost:8081/api/auth/email/verify?token=" + token;
	}

	public String generateResetPasswordVerificationUrl(User user) {
		String token = saveVerificationToken(user, VerificationTokenType.FORGOTPASSWORDTOKEN);
		return "http://localhost:4200/reset-password?token=" + token;
	}

	private String generateVerificationToken() {
		return UUID.randomUUID().toString();
	}

	private String saveVerificationToken(User user, VerificationTokenType tokenType) {
		VerificationToken verificationToken = new VerificationToken();
		verificationToken.setCreatedAt(LocalDateTime.now());
		verificationToken.setExpiresAt(LocalDateTime.now().plusMinutes(5));
		String token = generateVerificationToken();
		verificationToken.setToken(token);
		verificationToken.setUser(user);
		verificationToken.setTokenType(tokenType);
		tokenRepo.save(verificationToken);
		return token;
	}

	public void delete(VerificationToken verificationToken) {
		tokenRepo.delete(verificationToken);
	}

	public VerificationToken verifyToken(String token, VerificationTokenType tokenType) {
		VerificationToken savedToken = tokenRepo.findByToken(token);
		if (savedToken != null) {
			if (LocalDateTime.now().isAfter(savedToken.getExpiresAt())) {
				throw new VerificationTokenExpiryException("Link has been expired.", HttpStatus.BAD_REQUEST);
			}

			if (savedToken.getTokenType() != tokenType) {
				throw new VerificationTokenExpiryException("Invalid token Link", HttpStatus.BAD_REQUEST);
			}
			return savedToken;

		} else {
			throw new VerificationTokenExpiryException("Invalid Link or Link has been expired.",
					HttpStatus.BAD_REQUEST);
		}
	}
}

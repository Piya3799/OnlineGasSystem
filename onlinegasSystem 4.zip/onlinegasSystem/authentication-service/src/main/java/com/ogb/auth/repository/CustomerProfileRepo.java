package com.ogb.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogb.auth.entity.CustomerProfile;

public interface CustomerProfileRepo extends JpaRepository<CustomerProfile, Long> {

}

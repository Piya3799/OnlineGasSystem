package com.ogb.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogb.auth.entity.VerificationToken;

public interface VerificationTokenRepo extends JpaRepository<VerificationToken, Long> {

	VerificationToken findByToken(String token);
}

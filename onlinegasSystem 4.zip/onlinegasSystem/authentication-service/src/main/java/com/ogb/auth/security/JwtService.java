package com.ogb.auth.security;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ogb.auth.entity.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

	@Value("${jwt.secret}")
	private String secretString;

	@Value("${jwt.expiration}")
	private Long expiration;

	private Key generateKey() {
		byte[] keyBytes = Decoders.BASE64.decode(secretString);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	public String generateToken(User user) {

		Map<String, Object> claims = new HashMap<>();
		claims.put("id", user.getId());
		claims.put("role", user.getRole());
		return Jwts.builder().claims(claims).subject(user.getUsername())
				.expiration(new Date(System.currentTimeMillis() + expiration)).issuedAt(new Date())
				.signWith(generateKey()).compact();

	}
}

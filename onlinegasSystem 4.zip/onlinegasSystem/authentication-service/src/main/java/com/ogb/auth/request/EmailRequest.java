package com.ogb.auth.request;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmailRequest {

	private String to;
	private String from;
	private String subject;
	private String template;
	private Map<String, Object> properties;

}
package com.ogb.auth.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.ogb.auth.entity.Address;
import com.ogb.auth.exception.AddressNotFoundException;
import com.ogb.auth.repository.AddressRepository;

@Repository
public class AddressDao {

    @Autowired
    AddressRepository addressRepository;

    public Address getAddressById(Long id) {
        return addressRepository.findById(id)
                .orElseThrow(() -> new AddressNotFoundException("Address not found with ID: " + id, HttpStatus.BAD_REQUEST));
    }

    public Address saveNewAddress(Address address) {
        return addressRepository.save(address);
    }

    public void deleteAddress(Long id) {
        Address existAddress = getAddressById(id);
        addressRepository.delete(existAddress);
    }

    public Address updateAddress(Long id, Address updatingAddress) {
        Address existAddress = getAddressById(id);

        if (updatingAddress.getAddressLine() != null) {
            existAddress.setAddressLine(updatingAddress.getAddressLine());
        }
        if (updatingAddress.getCity() != null) {
            existAddress.setCity(updatingAddress.getCity());
        }
        if (updatingAddress.getDistrict() != null) {
            existAddress.setDistrict(updatingAddress.getDistrict());
        }
        if (updatingAddress.getState() != null) {
            existAddress.setState(updatingAddress.getState());
        }
        if (updatingAddress.getPincode() != null) {
            existAddress.setPincode(updatingAddress.getPincode());
        }

        return addressRepository.save(existAddress);
    }

    public Address getCustomerAddress(Long customerId) {
        return addressRepository.findByCustomerProfileId(customerId);
    }

    public Address getDistributorAddress(Long distributorId) {
        return addressRepository.findByDistributorProfileId(distributorId);
    }
}

package com.ogb.auth.dao;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ogb.auth.entity.User;
import com.ogb.auth.repository.AuthenticationRepository;
import com.ogb.auth.util.Role;

@Repository
public class AuthenticationDao {

	@Autowired
	AuthenticationRepository authenticationRepository;

	public User getUserById(Long id) {
		return authenticationRepository.findById(id).orElse(null);
	}

	public User getUserByUserName(String username) {
		return authenticationRepository.findByUsername(username);
	}

	public User saveUser(User user) {
		return authenticationRepository.save(user);
	}

	public List<User> getAllUsers() {
		return authenticationRepository.findAll().stream().filter(u -> u.getRole() != Role.ADMIN)
				.collect(Collectors.toList());
	}
	
	public boolean isUserExists(Long userId) {
		return authenticationRepository.existsById(userId);
	}

}

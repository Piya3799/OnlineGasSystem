package com.ogb.auth.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.ogb.auth.entity.DistributorProfile;
import com.ogb.auth.exception.UserNotFoundException;
import com.ogb.auth.repository.DistributorProfileRepo;

@Repository
public class DistributorProfileDao {

    @Autowired
    DistributorProfileRepo distributorProfileRepo;

    public DistributorProfile saveDistributor(DistributorProfile distributorProfile) {
        return distributorProfileRepo.save(distributorProfile);
    }

    public DistributorProfile getDistributorProfileById(Long id) {
        return distributorProfileRepo.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Distributor profile not found with ID: " + id, HttpStatus.NOT_FOUND));
    }

    public List<DistributorProfile> getAllDistributors() {
        return distributorProfileRepo.findAll();
    }
}

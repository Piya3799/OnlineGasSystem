package com.ogb.auth.entity;

import java.time.LocalDateTime;

import com.ogb.auth.util.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true, nullable = false)
	@NotBlank(message = "Username is required")
	@Email(message = "Invalid email format. ex:example@mail.com")
	private String username;

	@Column(nullable = false)
	@NotBlank(message = "Password is required")
	@Pattern(
	    regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$",
	    message = "Password must be at least 8 characters long, include an uppercase letter, lowercase letter, number, and special character"
	)
	private String password;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Role role;

	private boolean emailVerified = false;

	private boolean suspended = false;

	private LocalDateTime createdAt;

	private LocalDateTime passwordLastUpdatedAt;

}

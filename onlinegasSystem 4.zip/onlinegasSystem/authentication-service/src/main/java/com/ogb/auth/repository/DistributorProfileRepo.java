package com.ogb.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogb.auth.entity.DistributorProfile;

public interface DistributorProfileRepo extends JpaRepository<DistributorProfile, Long> {

}

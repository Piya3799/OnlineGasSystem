package com.ogb.auth.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ogb.auth.dao.AuthenticationDao;
import com.ogb.auth.entity.User;
import com.ogb.auth.entity.VerificationToken;
import com.ogb.auth.exception.AuthException;
import com.ogb.auth.exception.UserNotFoundException;
import com.ogb.auth.request.LoginRequest;
import com.ogb.auth.response.ApiResponse;
import com.ogb.auth.security.JwtService;
import com.ogb.auth.util.Role;
import com.ogb.auth.util.VerificationTokenType;

import jakarta.annotation.PostConstruct;

@Service
public class AuthenticationService {

	@Autowired
	AuthenticationDao authenticationDao;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtService jwtService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	EmailFeignClientService emailService;

	@Autowired
	VerificationTokenService verificationTokenService;

	@PostConstruct
	private void addAdmin() {
		User existAdmin = authenticationDao.getUserByUserName("admin@admin.com");
		if (existAdmin == null) {
			User admin = new User();
			admin.setUsername("admin@admin.com");
			admin.setPassword(passwordEncoder.encode("Admin@123"));
			admin.setEmailVerified(true);
			admin.setCreatedAt(LocalDateTime.now());
			admin.setRole(Role.ADMIN);
			authenticationDao.saveUser(admin);
		}
	}

	public ApiResponse<String> login(LoginRequest loginRequest) {
		StringBuilder token = new StringBuilder();
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
			if (authentication.isAuthenticated()) {
				User userByUserName = authenticationDao.getUserByUserName(loginRequest.getUsername());
				token.append(jwtService.generateToken(userByUserName));
			}
		} catch (Exception e) {
			throw new AuthException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ApiResponse<>("success", "Login successful", token.toString(), LocalDateTime.now());
	}

	public ApiResponse<User> register(User user) {
		user.setUsername(user.getUsername().toLowerCase());
		user.setCreatedAt(LocalDateTime.now());
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		User savedUser = authenticationDao.saveUser(user);
		emailService.sendEmailVerificationMail(savedUser);
		return new ApiResponse<>("success",
				"Customer registered successfully. A confirmation email has been sent to your email address.",
				savedUser, LocalDateTime.now());
	}

	public String emailVericationRequest(Long id) {
		User existUser = authenticationDao.getUserById(id);
		if (existUser != null) {
			if (!existUser.isEmailVerified()) {
				emailService.sendEmailVerificationMail(existUser);
			}
			return "Email already verified.";
		}
		return "Email has been sent to your email address.";
	}

	public boolean verifyEmail(String token) {
		VerificationToken verifiedToken = verificationTokenService.verifyToken(token, VerificationTokenType.EMAILTOKEN);
		User user = authenticationDao.getUserById(verifiedToken.getUser().getId());
		if (user == null) {
			throw new UserNotFoundException("Invalid user.", HttpStatus.BAD_REQUEST);
		}
		if (user.isEmailVerified()) {
			return false;
		} else {
			user.setEmailVerified(true);
			authenticationDao.saveUser(user);
			verificationTokenService.delete(verifiedToken);
			return true;
		}
	}

	public String passwordResetRequest(String email) {
		User existUser = authenticationDao.getUserByUserName(email);
		if (existUser != null) {
			emailService.sendPasswordRestMail(existUser);
		}
		return "If we found any account associated with this email, you will receive a mail to reset your password.";
	}

	public String resetPassword(String token, String newPassword) {
		VerificationToken verifiedToken = verificationTokenService.verifyToken(token,
				VerificationTokenType.FORGOTPASSWORDTOKEN);
		User user = authenticationDao.getUserById(verifiedToken.getUser().getId());
		if (user == null) {
			throw new UserNotFoundException("Invalid user.", HttpStatus.BAD_REQUEST);
		}
		if (passwordEncoder.matches(newPassword, user.getPassword())) {
			throw new AuthException("New password cannot be same as old password", HttpStatus.BAD_REQUEST);
		}
		user.setPassword(passwordEncoder.encode(newPassword));
		user.setPasswordLastUpdatedAt(LocalDateTime.now());
		authenticationDao.saveUser(user);
		verificationTokenService.delete(verifiedToken);
		return "Password has been reset successfully.";
	}

	public boolean isUserExists(Long userId) {
		return authenticationDao.isUserExists(userId);
	}
}

package com.ogb.auth;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ogb.auth.controller.AuthenticationController;
import com.ogb.auth.request.LoginRequest;
import com.ogb.auth.security.SecurityConfiguration;
import com.ogb.auth.service.AuthenticationService;
import com.ogb.auth.response.ApiResponse;

@WebMvcTest(AuthenticationController.class)
@AutoConfigureMockMvc(addFilters = false)
public class AuthenticationControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	AuthenticationService authenticationService;

	@MockBean
	SecurityConfiguration configuration;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void testLoginSuccess() throws Exception {
		LoginRequest loginRequest = new LoginRequest("test@example.com", "password");
		ApiResponse<String> mockResponse = new ApiResponse<>("success", "Login successful", "jwt-token", null);

		Mockito.when(authenticationService.login(Mockito.any(LoginRequest.class))).thenReturn(mockResponse);

		mockMvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(loginRequest))).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Login successful"))
				.andExpect(jsonPath("$.data").value("jwt-token"));
	}

	@Test
	public void testEmailVerificationLinkSendRequest() throws Exception {
		LoginRequest loginRequest = new LoginRequest("test@example.com", "password");
		ApiResponse<String> mockResponse = new ApiResponse<>("success", "Login successful", "jwt-token", null);

		Mockito.when(authenticationService.login(Mockito.any(LoginRequest.class))).thenReturn(mockResponse);

		mockMvc.perform(get("/email/request").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(loginRequest))).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Login successful"))
				.andExpect(jsonPath("$.data").value("jwt-token"));
	}
}


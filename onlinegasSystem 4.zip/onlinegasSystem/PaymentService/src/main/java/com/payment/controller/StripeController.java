
package com.payment.controller;

import com.payment.dto.ProductRequest;
import com.payment.dto.StripeResponse;
import com.payment.service.StripeService;
import com.stripe.exception.StripeException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product/v1")
@CrossOrigin("*")
public class StripeController {

    private final StripeService stripeService;

    public StripeController(StripeService stripeService) {
        this.stripeService = stripeService;
    }

    @PostMapping("/checkout") //customer
    public ResponseEntity<StripeResponse> checkoutProducts(@RequestBody ProductRequest productRequest) throws StripeException {
        StripeResponse stripeResponse = stripeService.checkoutProducts(productRequest);
        return ResponseEntity.status(HttpStatus.OK).body(stripeResponse);
    }
}

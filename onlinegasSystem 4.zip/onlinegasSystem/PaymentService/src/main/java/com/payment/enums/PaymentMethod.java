package com.payment.enums;

public enum PaymentMethod {
	CARD, UPI, NETBANKING, WALLET
}

package com.payment.dto;

import java.math.BigDecimal;
import com.payment.enums.PaymentMethod;
import lombok.Data;

@Data
public class PaymentRequest {
    private Long bookingId;
    private BigDecimal amount;
    private PaymentMethod method;
}
package com.payment.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payment.entity.Payment;
import com.payment.enums.PaymentStatus;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByStatus(PaymentStatus status);
    List<Payment> findByBookingId(Long bookingId);
Optional<Payment> findByStripeSessionId(String sessionId);

}

package com.payment.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.payment.enums.PaymentMethod;
import com.payment.enums.PaymentStatus;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "payments")
@Data
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Logical foreign key reference to Booking service
    @Column(name = "booking_id", nullable = false)
    private Long bookingId;

    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;

    @Enumerated(EnumType.STRING)
    private PaymentMethod method;

    private LocalDateTime paymentDate;

    private String transactionId;
    
    @Column(name = "stripe_session_id") 
    private String stripeSessionId;
}
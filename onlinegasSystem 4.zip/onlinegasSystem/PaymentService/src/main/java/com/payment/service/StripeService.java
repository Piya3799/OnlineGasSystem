package com.payment.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.payment.dto.ProductRequest;
import com.payment.dto.StripeResponse;
import com.payment.entity.Payment;
import com.payment.enums.PaymentMethod;
import com.payment.repository.PaymentRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

@Service
public class StripeService {

    @Value("${stripe.secretKey}")
    private String secretKey;

    @Autowired
    private PaymentService paymentService;

    public StripeResponse checkoutProducts(ProductRequest productRequest) throws StripeException {
        Stripe.apiKey = secretKey;

        long stripeAmount = productRequest.getAmount() * 100;

        if (productRequest.getCurrency().equalsIgnoreCase("INR") && stripeAmount < 4000) {
            throw new IllegalArgumentException("Minimum amount for INR must be at least ₹40.00 (4000 paisa)");
        }

        SessionCreateParams params = SessionCreateParams.builder()
            .setMode(SessionCreateParams.Mode.PAYMENT)
            .setSuccessUrl("http://localhost:8082/success?session_id={CHECKOUT_SESSION_ID}")
            .setCancelUrl("http://localhost:8082/cancel")
            .addLineItem(
                SessionCreateParams.LineItem.builder()
                    .setQuantity(productRequest.getQuantity())
                    .setPriceData(
                        SessionCreateParams.LineItem.PriceData.builder()
                            .setCurrency(productRequest.getCurrency())
                            .setUnitAmount(stripeAmount)
                            .setProductData(
                                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                    .setName(productRequest.getName())
                                    .build())
                            .build())
                    .build())
            .build();

        Session session = Session.create(params);

        Payment payment = new Payment();
        payment.setAmount(BigDecimal.valueOf(stripeAmount).movePointLeft(2)); // converts paise to INR
        payment.setMethod(PaymentMethod.CARD);
        payment.setBookingId(productRequest.getBookingId());
        payment.setStripeSessionId(session.getId());

        payment = paymentService.createPayment(payment);

        return StripeResponse.builder()
            .status("CREATED")
            .message("Stripe session created")
            .sessionId(session.getId())
            .sessionUrl(session.getUrl())
            .build();
    }
}

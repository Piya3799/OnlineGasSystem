package com.payment.controller;
 
import com.payment.entity.Payment;
import com.payment.enums.PaymentStatus;
import com.payment.repository.PaymentRepository;
import com.stripe.model.checkout.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
 
import java.util.Optional;
 
@RestController
@RequestMapping("/stripe")
@CrossOrigin("*")
public class StripeVerificationController {
 
	@Autowired
	private PaymentRepository paymentRepository;
 
	@GetMapping("/verify/{sessionId}") // admin
	public ResponseEntity<String> verifyPayment(@PathVariable String sessionId) {
		try {
			Session session = Session.retrieve(sessionId);
 
			Optional<Payment> optionalPayment = paymentRepository.findByStripeSessionId(sessionId);
			if ("complete".equals(session.getStatus())) {
				if (optionalPayment.isPresent()) {
					Payment payment = optionalPayment.get();
					payment.setStatus(PaymentStatus.SUCCESS);
					paymentRepository.save(payment);
					return ResponseEntity.ok("Payment verified and updated.");
				} else {
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Payment not found.");
				}
			} else {
				if (optionalPayment.isPresent()) {
					Payment payment = optionalPayment.get();
					payment.setStatus(PaymentStatus.FAILED);
					paymentRepository.save(payment);
					return ResponseEntity.ok("Payment failed.");
				}
				return ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED).body("Payment not completed.");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error verifying payment: " + e.getMessage());
		}
	}
}
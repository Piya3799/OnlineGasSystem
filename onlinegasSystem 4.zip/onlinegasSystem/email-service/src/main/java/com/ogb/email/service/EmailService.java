package com.ogb.email.service;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import com.ogb.email.entity.EmailRequest;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	@Autowired(required = true)
	JavaMailSender javaMailSender;

	@Autowired
	SpringTemplateEngine templateEngine;

	public void sendMail(EmailRequest emailRequest) throws MessagingException, UnsupportedEncodingException {

		MimeMessage mimeMessage = javaMailSender.createMimeMessage();

		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

		Context context = new Context();
		context.setVariables(emailRequest.getProperties());

		helper.setFrom("OnlineGasBooking@ogb.com", "OGB");

		helper.setTo(emailRequest.getTo());
		
		helper.setSubject(emailRequest.getSubject());
		
		String template = null;
		
		if (emailRequest.getTemplate() == null) {
			template = templateEngine.process("default", context);

		} 
		else {
			template = templateEngine.process(emailRequest.getTemplate(), context);
		}

		helper.setText(template, true);
		javaMailSender.send(mimeMessage);

	}
}

package com.ogb.email.controller;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ogb.email.entity.EmailRequest;
import com.ogb.email.service.EmailService;

import jakarta.mail.MessagingException;

@RestController
@RequestMapping("/api/email")
@CrossOrigin("*")
public class EmailController {

	@Autowired
	EmailService emailService;

	@PostMapping
	public String sendMail(@RequestBody EmailRequest emailRequest) {

		try {
			emailService.sendMail(emailRequest);
			return "Mail sent";
		} catch (UnsupportedEncodingException | MessagingException e) {
			return e.getMessage();
		}
	}

}
